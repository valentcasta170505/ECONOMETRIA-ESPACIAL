"""Núcleo reproducible de Spatial VAR Lab.

Las geometrías son reales (descargadas de una fuente externa); los indicadores
son sintéticos y TODOS los parámetros dinámicos son supuestos didácticos.
"""
from __future__ import annotations

import json
import unicodedata
from dataclasses import dataclass
from functools import lru_cache
from typing import Any

import numpy as np
import pandas as pd
import requests
from pyproj import Transformer
from scipy.spatial import cKDTree
from shapely.geometry import mapping, shape
from shapely.ops import transform, unary_union
from shapely.strtree import STRtree

SEED = 20261020
PERIODS = ("P1", "P2", "P3", "P4")
VARIABLES = {
    "Crecimiento económico (p.p.)": "growth",
    "Desempleo (p.p.)": "unemp",
    "Luces nocturnas (índice)": "nightlights",
}
VARIABLE_NAMES = tuple(VARIABLES)
VARIABLE_CODES = tuple(VARIABLES.values())
WEIGHT_NAMES = ("Queen · contigüidad", "KNN · 4 vecinos")
A = np.array([[0.52, -0.08, 0.06],
              [-0.28, 0.50, -0.025],
              [0.22, -0.07, 0.47]], dtype=float)
RHO = np.array([0.26, 0.16, 0.19], dtype=float)
HORIZON = 8
DANE_URL = ("https://geoportal.dane.gov.co/mparcgis/rest/services/Divipola/"
            "Serv_DIVIPOLA_MGN_2025/FeatureServer/319/query")
REPOSITORY_URL = ("https://raw.githubusercontent.com/ytolosa/mapas-colombia/main/"
                  "output/geojson/col_departamentos_real_nacional.geojson")
GEOBOUNDARIES_API = "https://www.geoboundaries.org/api/current/gbOpen/COL/ADM1/"


@dataclass
class Atlas:
    names: list[str]
    shapes: list[Any]
    coords: np.ndarray  # n x 2: lon, lat
    xy_metric: np.ndarray  # n x 2: metros; para cálculo de KNN
    geojson: dict
    source: str

    @property
    def n(self) -> int:
        return len(self.names)


def _get_json(url: str, params: dict | None = None, timeout: int = 25) -> dict:
    response = requests.get(url, params=params, timeout=timeout,
                            headers={"User-Agent": "SpatialVARLab-Streamlit/2.0"})
    response.raise_for_status()
    data = response.json()
    if not isinstance(data, dict):
        raise ValueError("La URL no devolvió un objeto JSON")
    return data


def fetch_remote_geojson() -> tuple[dict, str]:
    """Descarga usando fuentes alternativas (sin geometrías inventadas)."""
    attempts = [
        ("DANE · MGN 2025 (servicio oficial)", lambda: _get_json(
            DANE_URL,
            params={"where": "1=1", "outFields": "DPTO_CCDGO,DPTO_CNMBRE",
                    "returnGeometry": "true", "outSR": 4326,
                    "maxAllowableOffset": 0.01, "geometryPrecision": 4,
                    "f": "geojson"}, timeout=24)),
        ("Repositorio público de cartografía colombiana", lambda: _get_json(
            REPOSITORY_URL, timeout=22)),
        ("geoBoundaries · límites administrativos (respaldo)", lambda: _get_json(
            _get_json(GEOBOUNDARIES_API, timeout=12)["simplifiedGeometryGeoJSON"],
            timeout=24)),
    ]
    errors = []
    for label, getter in attempts:
        try:
            data = getter()
            if not isinstance(data.get("features"), list) or not data["features"]:
                raise ValueError("GeoJSON vacío o inválido")
            if "error" in data:
                raise ValueError(str(data["error"])[:100])
            # Validación completa, para no detenerse en una fuente inutilizable.
            normalize_atlas(data, label)
            return data, label
        except Exception as exc:
            errors.append(f"{label}: {type(exc).__name__}: {str(exc)[:120]}")
    raise RuntimeError("No se pudo cargar una cartografía válida.\n" + "\n".join(errors))


def _name_of(properties: dict) -> str:
    aliases = ("DPTO_CNMBRE", "dpto_nombre", "departamento", "nom_dpto",
               "nombre_dpt", "nombre", "shapeName", "NAME_1", "adm1_name",
               "name", "NOMBRE")
    keys = {str(k).casefold(): k for k in properties}
    for alias in aliases:
        key = keys.get(alias.casefold())
        if key is not None and properties.get(key):
            return str(properties[key]).strip().title()
    raise ValueError("No hay un campo reconocible con el nombre del departamento")


def _normalize_text(s: str) -> str:
    return "".join(ch for ch in unicodedata.normalize("NFKD", s.casefold())
                   if not unicodedata.combining(ch)).strip()


def normalize_atlas(data: dict, source: str = "Archivo GeoJSON") -> Atlas:
    """Normaliza 30-34 entidades ADM1 y calcula centroides en una proyección métrica."""
    if data.get("type") != "FeatureCollection":
        raise ValueError("Se requiere un GeoJSON de tipo FeatureCollection")
    buckets: dict[str, list] = {}
    display: dict[str, str] = {}
    for feat in data.get("features", []):
        if not isinstance(feat, dict) or not feat.get("geometry"):
            continue
        geom = shape(feat["geometry"])
        if geom.is_empty or geom.geom_type not in ("Polygon", "MultiPolygon"):
            continue
        name = _name_of(feat.get("properties") or {})
        key = _normalize_text(name)
        buckets.setdefault(key, []).append(geom)
        display[key] = name

    if not 30 <= len(buckets) <= 34:
        raise ValueError(f"Se esperan 30-34 departamentos/distritos ADM1; encontrados: {len(buckets)}")

    to_m = Transformer.from_crs("EPSG:4326", "EPSG:6933", always_xy=True)
    to_ll = Transformer.from_crs("EPSG:6933", "EPSG:4326", always_xy=True)
    keys = sorted(buckets, key=lambda s: s.casefold())
    names, shapes, coords, xy_metric, features = [], [], [], [], []
    for key in keys:
        geom = unary_union(buckets[key])
        if not geom.is_valid:
            geom = geom.buffer(0)
        if geom.is_empty:
            raise ValueError(f"Geometría inválida: {display[key]}")
        cent = transform(to_m.transform, geom).centroid
        lonlat = transform(to_ll.transform, cent)
        names.append(display[key]); shapes.append(geom)
        coords.append([lonlat.x, lonlat.y]); xy_metric.append([cent.x, cent.y])
        # Solo simplificamos lo que se dibuja; W Queen opera con geometría no simplificada.
        display_geom = geom.simplify(0.045, preserve_topology=True)
        features.append({"type": "Feature", "id": key,
                         "properties": {"_id": key, "departamento": display[key]},
                         "geometry": mapping(display_geom)})
    return Atlas(names, shapes, np.asarray(coords, dtype=float),
                 np.asarray(xy_metric, dtype=float),
                 {"type": "FeatureCollection", "features": features}, source)


def make_weights(atlas: Atlas) -> dict[str, np.ndarray]:
    """Queen por frontera/punto real; KNN por distancia entre centroides métricos."""
    n = atlas.n
    queen = np.zeros((n, n), dtype=float)
    tree = STRtree(atlas.shapes)
    for i, geom in enumerate(atlas.shapes):
        for j in tree.query(geom):
            j = int(j)
            if j <= i:
                continue
            other = atlas.shapes[j]
            if geom.boundary.intersects(other.boundary):
                queen[i, j] = queen[j, i] = 1.0

    knn = np.zeros((n, n), dtype=float)
    _, near = cKDTree(atlas.xy_metric).query(atlas.xy_metric, k=min(5, n))
    near = np.asarray(near).reshape(n, -1)
    for i, neighbors in enumerate(near):
        valid = [int(j) for j in neighbors if j != i][:min(4, n - 1)]
        knn[i, valid] = 1.0

    def standardized(w: np.ndarray) -> np.ndarray:
        s = w.sum(axis=1, keepdims=True)
        return np.divide(w, s, out=np.zeros_like(w), where=s > 0)
    return {WEIGHT_NAMES[0]: standardized(queen), WEIGHT_NAMES[1]: standardized(knn)}


def spatial_multipliers(w: np.ndarray) -> tuple[np.ndarray, ...]:
    eye = np.eye(len(w))
    return tuple(np.linalg.solve(eye - rho * w, eye) for rho in RHO)


def spatial_step(previous: np.ndarray, innovation: np.ndarray,
                 multipliers: tuple[np.ndarray, ...]) -> np.ndarray:
    rhs = previous @ A.T + innovation
    return np.column_stack([multipliers[j] @ rhs[:, j] for j in range(3)])


def synthetic_panel(atlas: Atlas, weights: dict[str, np.ndarray]) -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    n = atlas.n
    mult = spatial_multipliers(weights[WEIGHT_NAMES[1]])
    region = rng.normal(size=(n, 3)) * np.array([0.55, 0.85, 5.2])
    region = np.column_stack([mult[j] @ region[:, j] for j in range(3)])
    state = region.copy()
    base = np.array([3.2, 11.2, 54.0])
    rows = []
    for period in PERIODS:
        innovation = rng.normal(size=(n, 3)) * np.array([0.35, 0.55, 2.6])
        state = spatial_step(state, 0.30 * region + innovation, mult)
        vals = np.clip(state + base, [-5, 2, 0], [12, 26, 100])
        for i, name in enumerate(atlas.names):
            rows.append({"departamento": name, "periodo": period,
                         **{code: float(vals[i, j]) for j, code in enumerate(VARIABLE_CODES)}})
    return pd.DataFrame(rows)


def panel_period(panel: pd.DataFrame, names: list[str], period: str) -> pd.DataFrame:
    return panel.loc[panel.periodo == period].set_index("departamento").loc[names]


def global_moran(values: np.ndarray, w: np.ndarray, permutations: int = 999,
                 seed: int = SEED) -> dict:
    """I de Moran global y p bilateral por permutación reproducible."""
    v = np.asarray(values, dtype=float)
    z = v - v.mean()
    denom = float(z @ z)
    s0 = float(w.sum())
    if denom <= 1e-15 or s0 <= 0:
        return {"I": float("nan"), "E[I]": float("nan"), "p": float("nan")}
    n = len(v)
    observed = (n / s0) * float(z @ w @ z) / denom
    rng = np.random.default_rng(seed)
    perms = np.array([rng.permutation(z) for _ in range(permutations)])
    sim = (n / s0) * np.einsum("bi,ij,bj->b", perms, w, perms) / denom
    expected = -1 / (n - 1)
    p = (1 + np.count_nonzero(np.abs(sim - expected) >= abs(observed - expected))) / (permutations + 1)
    return {"I": float(observed), "E[I]": float(expected), "p": float(p)}


def moran_table(period_df: pd.DataFrame, w: np.ndarray,
                seed: int = SEED) -> pd.DataFrame:
    rows = []
    for j, (label, code) in enumerate(VARIABLES.items()):
        result = global_moran(period_df[code].to_numpy(), w, seed=seed + j)
        rows.append({"Variable": label, "I de Moran": round(result["I"], 4),
                     "E[I]": round(result["E[I]"], 4),
                     "p bilateral": round(result["p"], 4),
                     "Signo": "Positivo" if result["I"] >= 0 else "Negativo"})
    return pd.DataFrame(rows)


def _bh_rejections(p_values: np.ndarray, alpha: float) -> np.ndarray:
    p = np.asarray(p_values, dtype=float)
    m = len(p)
    order = np.argsort(p)
    ordered = p[order]
    eligible = np.where(ordered <= alpha * (np.arange(1, m + 1) / m))[0]
    accept = np.zeros(m, dtype=bool)
    if len(eligible):
        accept[order[:eligible[-1] + 1]] = True
    return accept


def local_moran(values: np.ndarray, w: np.ndarray, names: list[str],
                permutations: int = 499, alpha: float = .05, fdr: bool = False,
                seed: int = SEED) -> pd.DataFrame:
    """LISA exploratoria con permutación condicional (no causal)."""
    v = np.asarray(values, dtype=float)
    z = (v - v.mean()) / (v.std(ddof=0) + 1e-12)
    lag = w @ z
    observed = z * lag
    rng = np.random.default_rng(seed)
    pvalues = np.ones(len(v))
    for i in range(len(v)):
        neighbors = np.flatnonzero(w[i] > 0)
        if len(neighbors) == 0:
            continue
        others = np.delete(z, i)
        simulated = np.empty(permutations, dtype=float)
        for b in range(permutations):
            chosen = rng.choice(others, size=len(neighbors), replace=False)
            simulated[b] = z[i] * float(w[i, neighbors] @ chosen)
        center = float(simulated.mean())
        pvalues[i] = (1 + np.count_nonzero(
            np.abs(simulated - center) >= abs(observed[i] - center))) / (permutations + 1)
    significant = _bh_rejections(pvalues, alpha) if fdr else (pvalues <= alpha)
    clusters = []
    for i in range(len(v)):
        if w[i].sum() == 0:
            clusters.append("Sin vecinos")
        elif not significant[i]:
            clusters.append("No significativo")
        elif z[i] >= 0 and lag[i] >= 0:
            clusters.append("Alto–Alto")
        elif z[i] < 0 and lag[i] < 0:
            clusters.append("Bajo–Bajo")
        elif z[i] >= 0 and lag[i] < 0:
            clusters.append("Alto–Bajo")
        else:
            clusters.append("Bajo–Alto")
    return pd.DataFrame({"departamento": names, "I local": observed,
                         "p local": pvalues, "z": z, "Wz": lag,
                         "clúster": clusters})


def irf(w: np.ndarray, origin: int, shock: float,
        variable: int = 0, horizon: int = HORIZON) -> np.ndarray:
    """Shock único en h=0. Devuelve [h, depto, variable]."""
    n = len(w)
    path = np.zeros((horizon + 1, n, 3), dtype=float)
    mult = spatial_multipliers(w)
    previous = np.zeros((n, 3), dtype=float)
    for h in range(horizon + 1):
        s = np.zeros((n, 3), dtype=float)
        if h == 0:
            s[origin, variable] = float(shock)
        previous = spatial_step(previous, s, mult)
        path[h] = previous
    return path


def model_metadata(atlas: Atlas) -> dict:
    return {"app": "Colombia · Spatial VAR Lab", "data_type": "synthetic",
            "geography_source": atlas.source,
            "disclaimer": "No es estimación VAR ni evidencia causal; los valores económicos son simulados.",
            "seed": SEED, "periods": list(PERIODS), "variables": VARIABLES,
            "A_temporal": A.tolist(), "rho_spatial": RHO.tolist(),
            "W": list(WEIGHT_NAMES), "horizon": HORIZON}
