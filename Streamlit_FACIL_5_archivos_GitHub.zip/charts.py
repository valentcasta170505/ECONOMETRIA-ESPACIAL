"""Figuras Plotly para Spatial VAR Lab (Streamlit)."""
from __future__ import annotations

import html

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from engine import Atlas, RHO, VARIABLES, VARIABLE_CODES, WEIGHT_NAMES, HORIZON

INK, BLUE, ORANGE, TEAL = "#14233d", "#3562cf", "#f28c44", "#008f91"
PALETTES = ("Viridis", "Cividis", "Plasma", "RdBu", "Blues")
CLUSTER_COLORS = {
    "Alto–Alto": "#dc3545",
    "Bajo–Bajo": "#2860ad",
    "Alto–Bajo": "#ecad42",
    "Bajo–Alto": "#4bb3a7",
    "No significativo": "#c8d0dd",
    "Sin vecinos": "#778195",
}


def base_layout(fig: go.Figure, title: str, height: int = 480) -> go.Figure:
    fig.update_layout(template="plotly_white", title={"text": title, "font": {"size": 17}},
                      font={"color": INK, "family": "Arial"},
                      paper_bgcolor="white", plot_bgcolor="white", height=height,
                      margin=dict(l=26, r=20, b=25, t=75))
    return fig


def choropleth(atlas: Atlas, values: np.ndarray, title: str, colorscale="Viridis") -> go.Figure:
    ids = [f["id"] for f in atlas.geojson["features"]]
    fig = go.Figure(go.Choropleth(
        geojson=atlas.geojson, featureidkey="properties._id", locations=ids,
        z=np.asarray(values, dtype=float), text=atlas.names,
        hovertemplate="<b>%{text}</b><br>Valor simulado: %{z:.2f}<extra></extra>",
        colorscale=colorscale, marker_line_color="white", marker_line_width=0.6,
        colorbar=dict(title="Valor", thickness=13, len=0.8),
    ))
    fig.update_geos(fitbounds="locations", visible=False, projection_type="mercator")
    return base_layout(fig, title, 530)


def _outlines(atlas: Atlas, zfloor: float) -> tuple[list, list, list]:
    xs, ys, zs = [], [], []
    for feature in atlas.geojson["features"]:
        geom = feature["geometry"]
        parts = [geom["coordinates"]] if geom["type"] == "Polygon" else geom["coordinates"]
        for rings in parts:
            # Exteriores; los agujeros no son necesarios en la vista didáctica.
            for x, y in rings[0]:
                xs.append(x); ys.append(y); zs.append(zfloor)
            xs.append(None); ys.append(None); zs.append(None)
    return xs, ys, zs


def configure_3d(fig: go.Figure, title: str, ztitle: str,
                 height: int = 610, zrange=None) -> go.Figure:
    fig = base_layout(fig, title, height)
    scene = dict(
        bgcolor="#ffffff",
        xaxis=dict(title="Longitud (°)", backgroundcolor="white", gridcolor="#e6ecf4"),
        yaxis=dict(title="Latitud (°)", backgroundcolor="white", gridcolor="#e6ecf4"),
        zaxis=dict(title=ztitle, backgroundcolor="white", gridcolor="#e6ecf4"),
        camera=dict(eye=dict(x=1.45, y=1.45, z=1.0)),
        aspectmode="manual", aspectratio=dict(x=1.3, y=1.0, z=0.67),
    )
    if zrange is not None:
        scene["zaxis"]["range"] = zrange
    fig.update_layout(scene=scene, uirevision="territorio-spvar")
    return fig


def explorer_3d(atlas: Atlas, values: np.ndarray, title: str, palette: str) -> go.Figure:
    values = np.asarray(values)
    floor = float(values.min() - max(np.ptp(values) * 0.24, .5))
    x, y, z = _outlines(atlas, floor)
    fig = go.Figure()
    fig.add_trace(go.Scatter3d(x=x, y=y, z=z, mode="lines", name="Territorio",
                               line=dict(color="#92a6bd", width=2), opacity=.5,
                               hoverinfo="skip"))
    xstem, ystem, zstem = [], [], []
    for (lon, lat), val in zip(atlas.coords, values):
        xstem.extend([lon, lon, None]); ystem.extend([lat, lat, None])
        zstem.extend([floor, float(val), None])
    fig.add_trace(go.Scatter3d(x=xstem, y=ystem, z=zstem, mode="lines",
                               line=dict(color="#7c8da3", width=3),
                               hoverinfo="skip", showlegend=False))
    fig.add_trace(go.Scatter3d(
        x=atlas.coords[:, 0], y=atlas.coords[:, 1], z=values,
        mode="markers", name="Indicador", text=[html.escape(n) for n in atlas.names],
        hovertemplate="<b>%{text}</b><br>Valor simulado: %{z:.2f}<extra></extra>",
        marker=dict(size=8, color=values, colorscale=palette,
                    line=dict(color=INK, width=.5), showscale=True,
                    colorbar=dict(title="Valor", thickness=12, len=.65)),
    ))
    return configure_3d(fig, title, "Valor sintético")


def moran_scatter(values: np.ndarray, w: np.ndarray, names: list[str],
                  variable: str, period: str) -> go.Figure:
    z = (values - np.mean(values)) / (np.std(values, ddof=0) + 1e-12)
    lag = w @ z
    slope = float(z @ lag) / max(float(z @ z), 1e-12)
    line = np.linspace(float(z.min() - .25), float(z.max() + .25), 100)
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=z, y=lag, mode="markers", text=names,
                             hovertemplate="<b>%{text}</b><br>z = %{x:+.3f}<br>Wz = %{y:+.3f}<extra></extra>",
                             marker=dict(size=10, color=BLUE, line=dict(color=INK, width=.65)),
                             name="Departamentos"))
    fig.add_trace(go.Scatter(x=line, y=line * slope, mode="lines",
                             name=f"Pendiente: {slope:+.3f}",
                             line=dict(color=ORANGE, width=3)))
    fig.add_hline(y=0, line_dash="dot", line_color="#97a5b7")
    fig.add_vline(x=0, line_dash="dot", line_color="#97a5b7")
    base_layout(fig, f"Diagrama de Moran · {period}", 430)
    fig.update_xaxes(title="Variable estandarizada (z)")
    fig.update_yaxes(title="Rezago espacial (Wz)")
    return fig


def lisa_map(atlas: Atlas, local: pd.DataFrame, title: str) -> go.Figure:
    fig = go.Figure()
    ids = [f["id"] for f in atlas.geojson["features"]]
    # Un único mapa temático por clúster (en vez de una escala continua de Moran).
    for cluster, color in CLUSTER_COLORS.items():
        indexes = [i for i, x in enumerate(local["clúster"]) if x == cluster]
        if not indexes:
            continue
        fig.add_trace(go.Choropleth(
            geojson=atlas.geojson, featureidkey="properties._id",
            locations=[ids[i] for i in indexes], z=[1] * len(indexes),
            text=[atlas.names[i] for i in indexes],
            customdata=np.array([[float(local.iloc[i]["I local"]),
                                  float(local.iloc[i]["p local"])] for i in indexes]),
            colorscale=[[0, color], [1, color]], showscale=False,
            marker_line_color="white", marker_line_width=.7,
            hovertemplate="<b>%{text}</b><br>" + cluster +
                          "<br>I local: %{customdata[0]:+.3f}<br>p: %{customdata[1]:.3f}<extra></extra>",
            name=cluster, showlegend=True,
        ))
    fig.update_geos(fitbounds="locations", visible=False, projection_type="mercator")
    fig.update_layout(legend=dict(orientation="h", y=-.10, x=.0,
                                  font=dict(size=11)))
    return base_layout(fig, title, 530)


def _network_traces(atlas: Atlas, w: np.ndarray, path: np.ndarray,
                    origin: int, target_index: int, h: int, vmax: float) -> list:
    response = path[h, :, target_index]
    edges = []
    for recv in range(atlas.n):
        for src in np.flatnonzero(w[recv] > 0):
            if recv == src:
                continue
            flow = RHO[target_index] * w[recv, src] * response[src]
            if abs(flow) > 1e-10:
                edges.append((abs(flow), float(flow), int(src), recv))
    edges.sort(reverse=True)
    # Limitar trazos para evitar ralentizar navegadores móviles.
    edges = edges[:min(65, len(edges))]
    plus, minus = [[], [], []], [[], [], []]
    for _, flux, i, j in edges:
        buf = plus if flux >= 0 else minus
        buf[0].extend([atlas.coords[i, 0], atlas.coords[j, 0], None])
        buf[1].extend([atlas.coords[i, 1], atlas.coords[j, 1], None])
        buf[2].extend([float(response[i]), float(response[j]), None])
    positive = go.Scatter3d(x=plus[0], y=plus[1], z=plus[2], mode="lines",
                            line=dict(color=ORANGE, width=5), opacity=.64,
                            name="Canal positivo", hoverinfo="skip")
    negative = go.Scatter3d(x=minus[0], y=minus[1], z=minus[2], mode="lines",
                            line=dict(color=TEAL, width=5), opacity=.64,
                            name="Canal negativo", hoverinfo="skip")
    nodes = go.Scatter3d(
        x=atlas.coords[:, 0], y=atlas.coords[:, 1], z=response,
        text=[html.escape(x) for x in atlas.names], mode="markers",
        customdata=np.repeat(h, atlas.n),
        hovertemplate="<b>%{text}</b><br>h=%{customdata}<br>Respuesta: %{z:+.4f}<extra></extra>",
        marker=dict(size=5 + 10 * np.sqrt(np.abs(response) / max(vmax, 1e-12)),
                    color=response, cmin=-vmax, cmax=vmax, colorscale="RdBu_r",
                    showscale=True, colorbar=dict(title="Δ", thickness=13, len=.68),
                    line=dict(color=INK, width=.4)), name="Respuesta regional",
    )
    focus = go.Scatter3d(
        x=[atlas.coords[origin, 0]], y=[atlas.coords[origin, 1]],
        z=[float(response[origin])], mode="markers",
        text=[html.escape(atlas.names[origin])],
        hovertemplate="Origen: %{text}<br>Respuesta: %{z:+.4f}<extra></extra>",
        marker=dict(size=14, symbol="diamond", color="#f6b54a",
                    line=dict(color=INK, width=2)), name="Origen del shock",
    )
    return [positive, negative, nodes, focus]


def network_3d(atlas: Atlas, w: np.ndarray, path: np.ndarray,
               origin: int, target_index: int, initial_h: int,
               target_label: str) -> go.Figure:
    vmax = max(.1, float(np.max(np.abs(path[:, :, target_index]))))
    traces = _network_traces(atlas, w, path, origin, target_index, initial_h, vmax)
    frames = [go.Frame(name=str(h), data=_network_traces(
        atlas, w, path, origin, target_index, h, vmax)) for h in range(len(path))]
    fig = go.Figure(data=traces, frames=frames)
    fig.update_layout(
        updatemenus=[dict(type="buttons", showactive=False, x=.0, y=1.11,
                          buttons=[dict(label="▶ Reproducir", method="animate", args=[
                              None, dict(frame=dict(duration=750, redraw=True),
                                         fromcurrent=True, transition=dict(duration=100))]),
                                   dict(label="❚❚ Pausar", method="animate", args=[
                                       [None], dict(mode="immediate", frame=dict(duration=0, redraw=False))])])],
        sliders=[dict(active=int(initial_h), x=.13, y=-.02, len=.77,
                      currentvalue=dict(prefix="Horizonte h = "),
                      steps=[dict(label=str(h), method="animate", args=[
                          [str(h)], dict(mode="immediate", frame=dict(duration=0, redraw=True),
                                        transition=dict(duration=0))]) for h in range(len(path))])],
        margin=dict(l=10, r=10, b=50, t=90),
    )
    configure_3d(fig, f"Difusión interregional · {target_label}",
                 "Respuesta al shock", 680, [-1.18 * vmax, 1.18 * vmax])
    return fig


def response_curves(path: np.ndarray, origin: int) -> go.Figure:
    fig = make_subplots(rows=1, cols=3,
                        subplot_titles=["Crecimiento (p.p.)", "Desempleo (p.p.)",
                                        "Luces nocturnas (índice)"], horizontal_spacing=.075)
    h = np.arange(len(path))
    for j in range(3):
        local = path[:, origin, j]
        others = (path[:, :, j].sum(axis=1) - local) / (path.shape[1] - 1)
        fig.add_trace(go.Scatter(x=h, y=local, mode="lines+markers",
                                 line=dict(color=BLUE, width=3), name="Origen",
                                 legendgroup="origen", showlegend=j == 0), row=1, col=j + 1)
        fig.add_trace(go.Scatter(x=h, y=others, mode="lines+markers",
                                 line=dict(color=ORANGE, width=2, dash="dot"),
                                 name="Promedio otros", legendgroup="otros",
                                 showlegend=j == 0), row=1, col=j + 1)
        fig.update_xaxes(title_text="Horizonte", dtick=1, row=1, col=j + 1)
        fig.add_hline(y=0, line_color="#cbd5e1", row=1, col=j + 1)
    base_layout(fig, "Respuestas dinámicas de las tres ecuaciones", 390)
    fig.update_layout(legend=dict(orientation="h", y=-.35))
    return fig


def weights_comparison(path_queen: np.ndarray, path_knn: np.ndarray,
                       origin: int, target_index: int) -> go.Figure:
    fig = go.Figure()
    for path, name, color in ((path_queen, "Queen", BLUE),
                              (path_knn, "KNN (4)", ORANGE)):
        fig.add_trace(go.Scatter(x=list(range(len(path))), y=path[:, origin, target_index],
                                 mode="lines+markers", name=name,
                                 line=dict(color=color, width=3)))
    fig.add_hline(y=0, line_color="#cbd5e1")
    base_layout(fig, "Sensibilidad del resultado local a la matriz de pesos", 350)
    fig.update_xaxes(title="Horizonte h", dtick=1)
    fig.update_yaxes(title="Respuesta en el origen")
    return fig


def time_series(panel: pd.DataFrame, department: str, label: str) -> go.Figure:
    code = VARIABLES[label]
    source = panel[panel.departamento == department]
    fig = go.Figure(go.Scatter(x=source.periodo, y=source[code],
                               mode="lines+markers", line=dict(color=BLUE, width=3),
                               marker=dict(size=9)))
    base_layout(fig, f"Trayectoria sintética · {html.escape(department)}", 330)
    fig.update_yaxes(title=label)
    fig.update_xaxes(title="Período simulado")
    return fig
